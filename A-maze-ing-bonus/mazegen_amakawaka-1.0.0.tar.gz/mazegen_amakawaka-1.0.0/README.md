*This project has been created as part of the 42 curriculum by \<amakino\>, \<takawaka\>.*

# Description
A-Maze-ing is a robust, modular procedural maze generator and solver written in Python 3.10+. This application reads a structured key-value configuration file, generates a maze with guaranteed connectivity using randomized Kruskal's algorithm or deep-first search, and determines the absolute shortest route via Breadth-First Search (BFS).

To satisfy the 42 curriculum requirements, a procedurally generated "42" pattern is securely embedded at the geometric center of the maze.

# Instructions
## 1. Installation
Ensure Python 3.10+ is installed on your local environment. To install typing checks, PEP 8 static analyzers, and python packaging build tools:
```
make install
```

## 2. Running the Application
To run the main module with the default parameters defined in config.txt:
```
python3 a_maze_ing.py config.txt
```
Or, you can use the configured automation rule in the Makefile:
```
make run
```

## 3. Quality & Conformity Checks
To execute strict flake8 style-conformance and mypy static typing evaluation:
```
make lint
```
## 4. Packaging and Live Local Distribution (Peer-Review)
To demonstrate the python package compilation during your defense:
```
make build-package
```
This rule automatically triggers python-build and copies the output .whl and .tar.gz distributions directly to the root directory.

# Configuration File Format
The input configuration file (e.g., config.txt) must strictly maintain a single KEY=VALUE statement per line. Empty lines and comment lines starting with # are automatically ignored.

WIDTH       : The horizontal width of the maze (positive integer). [Example: WIDTH=20]
HEIGHT      : The vertical height of the maze (positive integer). [Example: HEIGHT=20]
ENTRY       : The coordinate indices of the entrance cell (x,y). [Example: ENTRY=0,0]
EXIT        : The coordinate indices of the exit cell (x,y). [Example: EXIT=10,10]
OUTPUT_FILE : The file name to which the generated maze will be written. [Example: OUTPUT_FILE=maze.txt]
PERFECT     : Activates perfect maze behavior if True (exactly one unique path). [Example: PERFECT=True]
SEED        : An optional key used to guarantee reproducibility via seed values. [Example: SEED=42]
ALGORITHM   :(Optional) Set your starting generation algorithm (Kruskal or DFS).

# Maze Generation Algorithm & Rationale

## 1. Randomized Kruskal's Algorithm
The core generator logic utilizes Kruskal's Spanning Tree Algorithm coupled with a Disjoint-Set (Union-Find) forest structure featuring path compression.

Connectivity: Kruskal's naturally prevents isolated cells or disjoint islands.

Perfect Loopless Trees: When PERFECT=True, the generator halts the wall-breaking phase precisely when all cells are unioned into a single spanning tree, ensuring exactly one path exists.

Controlled Open Loops: If PERFECT=False, we select approximately 10% of remaining uncarved walls and dismantle them. This builds natural loops without making corridors wider than 2 cells (such as $2 \times 3$ or $3 \times 2$ spaces, preventing any $3 \times 3$ open areas).

## 2. Depth-First Search (DFS) / Recursive Backtracker

As a premium feature, DFS generator logic has been fully implemented.

Why DFS?: While Kruskal's algorithm generates uniform mazes with numerous short branches, DFS tunnels persistently until it hits a dead end, then backtracks. This algorithm generates beautiful, long, highly-winding corridors which provide a greater visual puzzle experience.

# Solver Algorithm: Breadth-First Search (BFS)
In an unweighted 2D grid, BFS explores cell options uniformly like ripples in a pond.

Shortest Route Guarantee: The first time BFS encounters the target coordinates (EXIT), the route is mathematically guaranteed to be the absolute shortest route. Unlike Depth-First Search (DFS) which can return highly convoluted solutions, BFS ensures optimal traversal.

# Code Reusability & Packaged Module Usage
The entire generation and solving logic resides in the standalone python module src/mazegen. It is fully decoupled from I/O side effects, terminal rendering, or system calls.

Developers can easily install the generated package (mazegen-amakawaka) using pip and import it into future applications as follows:
```
from mazegen import MazeGenerator

# Initialize the generator (Width: 20, Height: 15, Seed: 42)
generator = MazeGenerator(width=20, height=15, seed=42)

# Generate a perfect loopless matrix
grid = generator.generate(perfect=True)

# Solve coordinates using Breadth-First Search (BFS)
path = generator.solve(start=(0, 0), end=(19, 14))
print("Shortest path sequence:", path)
```
# Interactive Extended Menu Bonuses
We have implemented 5 advanced interface bonuses:

🌈 Gaming RGB wave mode: Sine-wave calculated real-time 24-bit terminal color animations.

🧠 Multi-Algorithm Toggle: Switch between Randomized Kruskal and DFS generators seamlessly.

🎬 Construction Animation: Watch the exact step-by-step mathematical carving of the maze on screen.

🎮 Interactive Mode: Play the maze yourself in an arcade-like experience using W/A/S/D keys. Your step history is evaluated against optimal BFS paths!

🧱 Theme Texture Customization: Cycle through beautiful tile sets on-the-fly (#, █, ▓, ░, *, +).

# Team & Project Management
## amakino
Formulated parsing architecture, rigorous configuration validators, automated Makefile targets, typing compliance checks, and bilingual documentation.
## takawaka
Authored Randomized Kruskal backend, Union-Find forest compression, BFS pathfinder, and procedurally mapped the geometric "42" coordinates.

# Anticipated Planning & Evolution
## Original Plan
 We planned a basic, single-script file executing everything sequentially.
## Evolution
Ch.VI requirements demanded strict module packaging. We modularized the codebase, extracting algorithmic computation into generator.py, validating config parsing inside parser.py, and implementing UI operations inside ui.py.

# Retrospective
What worked: Decoupling the pathfinder from the generation state allowed isolated, granular testing.

What could be improved: Moving coordinate representations into immutable 2D tuples earlier would have prevented minor transformation bugs.

# Tools Used
Python 3.10+, git, flake8, mypy, python-build.

# Resources & AI Usage
## Resources:
Resources: Graph Theory on Spanning Trees, PEP 257 (Docstrings Guidelines), and Python Packaging conventions.

AI Usage: AI was leveraged to generate boilerplates for Google-style docstrings, cross-check parsing corner cases (such as folder targets crashing standard file operations), and help translate technical concepts. Every suggested block was manually audited, adjusted for flake8 length constraints, and extensively validated locally.

全域木を用いた迷路作成方法 - Qiita
https://qiita.com/kerochan/items/737dedac2175244cdd72

https://qiita.com/kaityo256/items/b2e504c100f4274deb42

https://infomisc.blog/?p=2367

## AI Usage:
AI tools were utilized to generate boilerplate Google-style docstrings, validate complex parser boundary conditions (such as ensuring directories do not crash file operations), and help translate technical design patterns between English and Japanese sections of the document.


A-Maze-ing (日本語版)

# Description
A-Maze-ing は、Python 3.10以降で開発された頑健かつモジュール化された迷路生成・解析システムです。設定ファイルを安全にパースし、ランダム化クラスカル法または深さ優先探索（DFS）を用いて整合性のある全域接続迷路を構築し、幅優先探索（BFS）により入り口から出口までの最短経路を特定します。

42の課題要件を満たすため、迷路の幾何学的な中心部分に「42」という形状の閉鎖セル領域が自動的に埋め込まれます。



# Instructions
## 1. 依存関係のインストール
静的解析ツール、型チェッカー、およびパッケージビルドツールを仮想環境に配備します：
```
make install
```

## 2. アプリケーションの実行
デフォルトの設定ファイル（config.txt）を使用して迷路を生成・出力するには以下のコマンドを実行します。
```
python3 a_maze_ing.py config.txt
```
または、Makefileに定義された実行コマンドを利用することも可能です：
```
make run
```

## 3. Verification & Linting
コード品質を保つために flake8 と mypy によるチェックを行います：
```
make lint
```


## 4. パッケージ再ビルドとローカル配備（評価対応）
ピア評価時に、目の前でパッケージをビルドし成果物ファイルを配備するデモを行う場合、以下を実行します：
```
make build-package
```
これにより自動的に build が走ったのち、生成された .whl と .tar.gz ファイルがプロジェクトのルートに複製・配備されます。

# 設定ファイルの構造
入力パラメータを定義する設定ファイル（例：config.txt）は、1行ごとに KEY=VALUE のペアで記述する必要があります。空行や \# から始まる行はコメントとして自動的に無視されます。

WIDTH       : 迷路の横幅（正の整数）。 [例: WIDTH=20]
HEIGHT      : 迷路の縦幅（正の整数）。 [例: HEIGHT=20]
ENTRY       : スタート地点の座標（x,y 形式）。 [例: ENTRY=0,0]
EXIT        : ゴール地点の座標（x,y 形式）。 [例: EXIT=10,10]
OUTPUT_FILE : 迷路データが出力・保存されるファイル名。 [例: OUTPUT_FILE=maze.txt]
PERFECT     : True のとき、一意な正解経路のみを持つ「完全迷路」を構築。 [例: PERFECT=True]
SEED        : 乱数生成のシード値。同じ迷路を再生成可能にします。 [例: SEED=42]
ALGORITHM   : （オプション）初期の迷路生成アルゴリズム（Kruskal または DFS）。

# 迷路生成アルゴリズムの選定理由

## ランダム化クラスカル法 (Kruskal's Algorithm)
経路圧縮を備えた不連続集合構造（Union-Find木）と、最小全域木（MST）問題の応用を組み合わせて実装しました。

選定理由: 全体の接続性が数学的に保証され、孤立した不要領域を作りません。

完全・不完全制御: PERFECT=True の場合、全マスが1つのSpanning Treeに接続した時点で壁破壊を終了します。PERFECT=False の場合は、残存壁の約10%をランダムに追加で壊し、通路幅が3マス（$3 \times 3$）以上にならないように注意しながら、自然なループ（ショートカット）を形成します。

## 深さ優先探索 (DFS / Recursive Backtracker)
ボーナス機能として、DFSベースのジェネレータも搭載しました。

選定理由: クラスカル法が均等で短い分岐を多く作るのに対し、DFSは行き止まりに当たるまで一方向に深く突き進みます。これにより、「非常に長く、複雑に曲がりくねった一本道」が生まれ、パズルとしての難易度が格段に向上します。


## 最短経路ソルバー: 幅優先探索 (BFS)

迷路のようにすべてのセルの移動コストが均等な2Dグリッドにおいて、BFSは波紋のように四方に一歩ずつ探索を広げます。

選定理由: 最短経路探索の仕様において、BFSが最初にゴールに到達した経路は数学的に100%「最短」であることが保証されます。最初に見つかった経路を返すDFSソルバー（遠回りをする可能性がある）と異なり、常に最適ルートを導出できます。


### コード再利用性（パッケージ仕様）
迷路生成ロジックはすべて src/mazegen 内に完全にカプセル化されており、UIやコンソール入力などの副作用から完全に分離されています。

評価Ch.VIに準拠しており、生成された .whl パッケージを pip でインストールすることで、別のPythonプログラムから以下のようにインポートして再利用可能です：
```
from mazegen import MazeGenerator

# インスタンスの初期化 (20x15, SEED=42)
generator = MazeGenerator(width=20, height=15, seed=42)

# 完全迷路を生成（2次元ビットマスク配列を返却）
grid = generator.generate(perfect=True)

# BFSで最短経路を特定
path = generator.solve(start=(0, 0), end=(19, 14))
print("最短経路:", path)
```


## 搭載している5つのアドバンスド・ボーナス機能
🌈 ゲーミングカラーモード: 正弦波を利用してリアルタイムに24bitフルカラーのRGBグラデーション波を描画します。

🧠 複数アルゴリズムの実装: クラスカル法とDFS法を、再生成メニューからいつでもシームレスに切り替えて迷路を体験できます。

🎬 リアルタイム生成アニメーション: 迷路の壁が1マスずつプロシージャルに削られていく様子をなめらかにアニメーション描画します。

🎮 WASDプレイゲーム: ミニアーケードのように W/A/S/D キーでプレイヤー（@）を動かして脱出を目指す対話型ゲーム。クリア時に最短歩数との比較でスコアが算出されます！

🧱 豊富な壁テーマ切替: 迷路をレンダリングする壁のタイル文字をその場で動的に変更できます（#, █, ▓, ░, *, +）。


# Team & Project Management
## amakino
パース検証チェック、Makefile自動化、flake8/mypyなどのコーディング標準（PEP 8）チェック適合確認、日英README作成を担当。
## takawaka
迷路生成（クラスカル法）、Union-Find木構造、BFS経路ソルバーの実装、中央への「42」形状マッピング処理の実装を担当。

# 計画の変遷
## Original Plan
単一のPythonファイル内で順番に読み込んで出力する軽量なスクリプトを想定。
## Evolution
Ch.VIの「ライブラリパッケージ化要件」を満たすため、ディレクトリ構造を src/mazegen 配下に再編。さらに肥大化を防ぐために生成コアを generator.py、パースを parser.py、描画UI・ボーナス操作を ui.py へと高度にモジュール分割しました。

# レトロスペクティブ（振り返り）
うまくいった点: 迷路生成部分とBFS最短経路解析部分を切り分けたことで、結合前にそれぞれを独立してテスト・開発できました。

改善点: 座標管理を早い段階でタプル (x, y) に統一していれば、インデックス変換に伴うバグをより早く回避できました。

# 参照リソース ＆ AIアシスタント使用方法

リソース: 最小全域木（MST）問題、幅優先探索（BFS）の実装方法、PEP 257 docstring ガイドライン。

グラフ理論（Spanning Tree、Union-Find構造）に関する仕様ドキュメント。

AIアシスタントの使用実績: Google標準Docstringのひな形作成、不正なパス入力（ファイルではなくフォルダを渡された場合など）を回避するパーサーエラー網羅性テストの補助、および日英の翻訳・記述チェックにAIを活用しました。すべての提案コードは、手動でリファクタリング、 flake8の79文字規制への適合修正、およびローカル環境での十分な実行・型テストを経てマージされています。

幅優先探索（BFS）によるグリッド探索アルゴリズム、PEP 257規約ガイドライン。
https://qiita.com/kerochan/items/737dedac2175244cdd72

https://qiita.com/kaityo256/items/b2e504c100f4274deb42

https://infomisc.blog/?p=2367

## AI Usage:
Google形式（Google Style）のDocstringのテンプレート生成、ファイルが存在しない際やフォルダを指定された際のパースエラーケースの網羅性チェック、およびREADMEにおける日英間のテクニカルな記述対応の補助にAIアシスタントを活用しました。出力されたコードおよびドキュメントは、型ヒントから処理整合性まで、すべて手動で精査およびテストした上でマージされています。
